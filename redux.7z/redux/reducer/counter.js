import { COUNTER_INCREASE, COUNTER_REDUCE } from "../type/counter";

let initState = {
  count: 10000,
};

const counter = (state = initState, action) => {
  const count = state.count;
  console.log(99999, action);
  switch (action.type) {
    case COUNTER_INCREASE:
      return { count: count + 1 };
    case COUNTER_REDUCE:
      return { count: count - 1 };
    default:
      return state;
  }
};

export default counter;
