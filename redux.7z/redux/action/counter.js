import { COUNTER_INCREASE, COUNTER_REDUCE } from "../type/counter";

export default {
  counter: {
    increase: (dispatch, payload) => {
      dispatch({
        type: COUNTER_INCREASE,
        payload,
      });
    },
    reduce: (dispatch, payload) => {
      dispatch({
        type: COUNTER_REDUCE,
        payload,
      });
    },
  },
};
