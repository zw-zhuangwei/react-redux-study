import counter from "./counter";

let action = Object.assign({}, counter);

export default action;
