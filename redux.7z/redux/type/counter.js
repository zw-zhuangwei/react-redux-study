export const COUNTER_INCREASE = Symbol("COUNTER_INCREASE");
export const COUNTER_REDUCE = Symbol("COUNTER_REDUCE");
